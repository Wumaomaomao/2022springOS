#ifndef __CONST_H__
#define __CONST_H__

#define TRUE         1
#define FALSE        0

#define NULL         ((void*)0)

#endif
